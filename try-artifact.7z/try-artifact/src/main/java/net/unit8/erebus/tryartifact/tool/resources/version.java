package net.unit8.erebus.tryartifact.tool.resources;

public final class version extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "full", "9-ea+167-jigsaw-nightly-h6342-20170427" },
            { "jdk", "9" },
            { "release", "9-ea" },
        };
    }
}
