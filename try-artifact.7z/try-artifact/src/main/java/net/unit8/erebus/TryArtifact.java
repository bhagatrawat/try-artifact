package net.unit8.erebus;

import net.unit8.erebus.tryartifact.tool.TryJShellToolBuilder;

/**
 * @author kawasima
 * @author Bhagat Singh
 */
public class TryArtifact {
    /**
     * Launch the tool.
     *
     * @param arguments the command-line arguments (including options), if any
     * @throws Exception an unexpected fatal exception
     */
    public static void main(String[] arguments) throws Exception {
        TryJShellToolBuilder.builder().run(arguments);
    }
}
