package net.unit8.erebus.tryartifact.command;

import jdk.jshell.SourceCodeAnalysis;
import jline.TerminalFactory;
import net.unit8.erebus.ArtifactSearcher;
import net.unit8.erebus.Erebus;
import net.unit8.erebus.tryartifact.tool.TryJShellTool;
import org.eclipse.aether.artifact.Artifact;
import org.eclipse.aether.collection.DependencyCollectionException;
import org.eclipse.aether.resolution.DependencyResolutionException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @author kawasima
 */
public class TryArtifactCommandRegister {
    public void register(TryJShellTool repl) {
        ArtifactSearcher searcher = new ArtifactSearcher();
        Erebus erebus = new Erebus.Builder().build();
        /** Register /resolve command */
        repl.registerCommand(new TryJShellTool.Command("/resolve", "Resolve an artifact\n" +
                " spec is <groupId>:<artifactId>[:<extension>[:<classifier>]]:<version>",
                arg -> {
                    if (arg.isEmpty()) {
                        repl.hard("/resolve requires a maven spec argument");
                        return false;
                    } else {
                        try {
                            List<File> artifacts = erebus.resolveAsFiles(arg);
                            artifacts.stream().map(File::getPath)
                                    .forEach(path -> {
                                        repl.getState().addToClasspath(
                                                TryJShellTool.toPathResolvingUserHome(path).toString());
                                        repl.fluff("Path %s added to classpath", path);
                                    });
                            return true;
                        } catch (DependencyCollectionException |
                                DependencyResolutionException |
                                IllegalArgumentException e) {
                            repl.errormsg("%s", e.getMessage());
                            return false;
                        }
                    }
                },
                (code, cursor, anchor) -> {
                    List<SourceCodeAnalysis.Suggestion> results = new ArrayList<>();
                    if (code.length() == 0) return results;
                    try {
                        List<Artifact> artifacts = searcher.searchIncremental(code);
                        artifacts.stream()
                                .map(a -> new TryJShellTool.ArgSuggestion(a.toString()))
                                .forEach(results::add);
                        anchor[0] = 0; // code.length();
                    } catch (IOException | IllegalArgumentException ignore) {

                    }
                    return results;
                }
                ,
                TryJShellTool.CommandKind.REPLAY));

        /** Register /cls command */
        repl.registerCommand(new TryJShellTool.Command("/cls",
                arg -> {
                    try {
                        if (System.getProperty("os.name").toLowerCase(Locale.US).contains(TerminalFactory.WINDOWS)) {
                            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
                        } else {
                            System.out.print("\033[H\033[2J");
                            System.out.flush();
                        }
                        return true;
                    } catch (IOException | InterruptedException e) {
                        repl.errormsg("%s", e.getMessage());
                        return false;
                    }
                },
                TryJShellTool.EMPTY_COMPLETION_PROVIDER));
    }

}
